this is an estate app with realtime chat funtionality
