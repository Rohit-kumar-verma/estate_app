export const navLinks = [
    {
      id: "home",
      title: "Home",
      current: true,
      url:"/"
    },
    {
      id: "about",
      title: "About",
      current: false,
      url:"/about"
    },
    {
      id: "contact",
      title: "Contact",
      current: false, 
      url:"/contact"
    },
    {
      id: "agents",
      title: "Agents",
      current: false, 
      url:"/agents"
    },
  ];